from django.shortcuts import render, HttpResponse, redirect
from .models import User
from django.contrib import messages
import bcrypt

# Create your views here.

def index(request):
    print "in index route"

    return render(request, 'login/index.html')

def registration(request):
    print "in registration route"
    print "request.method is:", request.method
    if request.method == "POST":
        print "request.method == POST"
        errors = User.objects.basic_validator(request.POST)
        if request.POST['action'] == 'registration':
            print " in request.POST['action'] == 'registraion' "
            if len(errors):
                for tag, error in errors.iteritems():
                    messages.error(request, error, extra_tags = tag)
                return redirect('/')
            else:
                print "passed registration checks"
                request.session['action'] = request.POST['action']
                
                # use Bcrypt
                pw = request.POST['password']
                print "pw is: ", pw
                hash_pw = bcrypt.hashpw(pw.encode(), bcrypt.gensalt())
                print "hash_pw is: ", hash_pw
                
                all_users = []

                new_user = User.objects.create(fname = request.POST['fname'], lname = request.POST['lname'], email = request.POST['email'], password = hash_pw)
                request.session['id'] = new_user.id
                all_users.append(new_user)

                print "new_user is: ", new_user
                print "all_users is: ", all_users
                print "new_user.id is: ", new_user.id

                print "redirecting to success"
                return redirect('/success')
    else:
        print "request.method == request.GET"

    return redirect('/')

def login(request):
    print "in login route"

    if request.method == "POST":
        if request.POST['action'] == "login":
            hash1 = User.objects.filter(email = request.POST['login_email'])
            request.session['id'] = hash1[0].id
            print "request.session['id'] is: ", request.session['id']
            print "hash1 is: ", hash1[0].password
            pw = request.POST['login_password']
            if bcrypt.checkpw(pw.encode(), hash1[0].password.encode()):
                print "passwords match"
                return redirect('/success')
            else: 
                print "passwords don't match"
                return redirect('/')
    else:
        print "redirecting to index"
        return redirect('/')

def success(request):
    print "in success route"

    if request.session['action'] == "registration":
        context = {
            "user": User.objects.get(id = request.session['id']),
            "message": "Successfully registered!"
        }
    if request.session['action'] == "login":
        context = {
            "user": User.objects.get(id = request.session['id']),
            "message": "Successfully logged in!"
        }

    return render(request, 'login/success.html', context)